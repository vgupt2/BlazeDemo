package blazedemo.test.packages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import blazedemo.uipages.packages.BookingConfirmation;
import blazedemo.uipages.packages.BookingFlight;
import blazedemo.uipages.packages.SearchFlight;
import blazedemo.uipages.packages.SelectFlight;

public class TestCasesExecution {
	
	public static WebDriver driver;
	
	public static void main(String[] args) throws InterruptedException {
		try {		
			System.setProperty("webdriver.chrome.driver",
					"C:\\Softwares\\SeleniumDependencies\\chromedriver_win32\\chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://blazedemo.com/");
			SearchFlight searchFlight = PageFactory.initElements(driver, SearchFlight.class);
			searchFlight.SearchFlightPage("Boston", "Cairo");
			searchFlight.clickFindFlights();
			SelectFlight selectFlight = PageFactory.initElements(driver, SelectFlight.class);
			selectFlight.selectFlightforBookings("43", "Virginia", "1:43 AM", "9:45 PM", "$472.56");
			BookingFlight bookingFlight = PageFactory.initElements(driver, BookingFlight.class);
			bookingFlight.purchaseFlight("Vikash", "Hebbal", "Bangalore", "karnataka", "560010", "American Express",
					"1000012444", "12", "2022", "Vikash Gupta");
			BookingConfirmation bookingConfirmation = PageFactory.initElements(driver, BookingConfirmation.class);
			bookingConfirmation.TicketConfirmation("Thank you for your purchase today!");
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
