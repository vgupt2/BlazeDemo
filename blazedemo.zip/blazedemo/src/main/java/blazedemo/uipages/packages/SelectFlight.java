package blazedemo.uipages.packages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class SelectFlight {

	WebDriver driver;

	public SelectFlight(WebDriver driver) {
		this.driver = driver;
	}

//	@FindBy(how = How.XPATH, using = "/html/body/div[2]/table/tbody/tr[2]/td[2]")
//	@CacheLookup
//	WebElement FlightId;
//
//	@FindBy(how = How.XPATH, using = "/html/body/div[2]/table/tbody/tr[1]/td[3]")
//	@CacheLookup
//	WebElement Airline;
//
//	@FindBy(how = How.XPATH, using = "/html/body/div[2]/table/tbody/tr[1]/td[4]")
//	@CacheLookup
//	WebElement DepartsTime;
//
//	@FindBy(how = How.XPATH, using = "/html/body/div[2]/table/tbody/tr[1]/td[5]")
//	@CacheLookup
//	WebElement ArrivesTime;
//
//	@FindBy(how = How.XPATH, using = "/html/body/div[2]/table/tbody/tr[1]/td[6]")
//	@CacheLookup
//	WebElement Price;
//
//	@FindBy(how = How.XPATH, using = "/html/body/div[2]/table/tbody/tr[1]/td[1]/input")
//	@CacheLookup
//	WebElement findFlight;

	public void selectFlightforBookings(String flightId, String airline, String arriveTime, String departTime,
			String price) {
		try {

			Thread.sleep(1000);
			String expectedVerifyFlighid = flightId;
			String actualVerifyFlighid = driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr[1]/td[2]")).getText();
			System.out.println(actualVerifyFlighid);
			Thread.sleep(1000);
			String expectedVerifyAirline = airline;
			String actualVerifyAirline = driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr[1]/td[3]")).getText();
			System.out.println(actualVerifyAirline);
			Thread.sleep(1000);
			String expectedVerifyDepartsTime = arriveTime;
			String actualVerifyDepartsTime =driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr[1]/td[4]")).getText();
			System.out.println(actualVerifyDepartsTime);
			Thread.sleep(1000);
			String expectedVerifyArrivesTime = departTime;
			String actualVerifyArrivesTime =driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr[1]/td[5]")).getText();
			System.out.println(actualVerifyArrivesTime);
			Thread.sleep(1000);
			String expectedVerifyPrice = price;
			String actualVerifyPrice =driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr[1]/td[6]")).getText();
			System.out.println(actualVerifyPrice);
			Thread.sleep(1000);
			driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr[1]/td[1]/input")).click();
			if (expectedVerifyFlighid.equalsIgnoreCase(actualVerifyFlighid) && expectedVerifyAirline.equalsIgnoreCase(actualVerifyAirline) && 
					expectedVerifyDepartsTime.equalsIgnoreCase(actualVerifyDepartsTime) && expectedVerifyArrivesTime.equalsIgnoreCase(actualVerifyArrivesTime)
					&& expectedVerifyPrice.equalsIgnoreCase(actualVerifyPrice))
			{
				driver.findElement(By.xpath("/html/body/div[2]/table/tbody/tr[1]/td[1]/input")).click();
			}	

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
