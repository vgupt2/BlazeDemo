package blazedemo.uipages.packages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class SearchFlight {

	WebDriver driver;

	public SearchFlight(WebDriver driver) {
		this.driver = driver;
	}

	public void SearchFlightPage(String departureCity, String distinationCity) {
		try {
			
			Select dropdownDepart = new Select(driver.findElement(By.name("fromPort")));
			dropdownDepart.selectByVisibleText(departureCity);
			Select dropdownDestination = new Select(driver.findElement(By.name("toPort")));
			dropdownDestination.selectByVisibleText(distinationCity);		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickFindFlights() {

		try {
			driver.findElement(By.xpath("/html/body/div[3]/form/div/input")).click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
