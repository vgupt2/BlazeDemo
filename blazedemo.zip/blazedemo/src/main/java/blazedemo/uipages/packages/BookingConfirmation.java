package blazedemo.uipages.packages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class BookingConfirmation {

	WebDriver driver;

	public BookingConfirmation(WebDriver driver) {
		this.driver = driver;
	}


	public void TicketConfirmation(String confirmationMessage) {
		try {
				String expectedConfirmationMessage = confirmationMessage;
				String actualConfirmationMessage = driver.findElement(By.xpath("/html/body/div[2]/div/h1")).getText();
				if(actualConfirmationMessage.equalsIgnoreCase(expectedConfirmationMessage)) {
					driver.quit();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
