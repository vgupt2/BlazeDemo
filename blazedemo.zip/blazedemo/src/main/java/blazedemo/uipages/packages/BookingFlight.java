package blazedemo.uipages.packages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class BookingFlight {
	WebDriver driver;

	public BookingFlight(WebDriver driver) {
		this.driver = driver;
	}
//
//	@FindBy(how = How.XPATH, using = "\"//*[@id=\\\"inputName\\\"]\"")
//	@CacheLookup
//	WebElement inputName;
//
//	@FindBy(how = How.XPATH, using = "//*[@id=\\\"address\\\"]")
//	@CacheLookup
//	WebElement address;
//
//	@FindBy(how = How.XPATH, using = "//*[@id=\\\"city\\\"]")
//	@CacheLookup
//	WebElement city;
//
//	@FindBy(how = How.XPATH, using = "//*[@id=\\\"state\\\"]")
//	@CacheLookup
//	WebElement state;
//	
//	@FindBy(how = How.XPATH, using = "//*[@id=\\\"zipCode\\\"]")
//	@CacheLookup
//	WebElement zipcode;
//	
//	@FindBy(how = How.ID, using = "cardType")
//	@CacheLookup
//	WebElement cardType;
//
//	@FindBy(how = How.ID, using = "creditCardNumber")
//	@CacheLookup
//	WebElement creditCardNumber;
//	
//	@FindBy(how = How.XPATH, using = "//*[@id=\\\"creditCardMonth\\\"]")
//	@CacheLookup
//	WebElement creditCardMonth;
//
//	@FindBy(how = How.XPATH, using = "//*[@id=\\\"creditCardYear\\\"]")
//	@CacheLookup
//	WebElement creditCardYear;
//
//	@FindBy(how = How.ID, using = "nameOnCard")
//	@CacheLookup
//	WebElement nameOnCard;
//
//	@FindBy(how = How.NAME, using = "/html/body/div[2]/form/div[11]/div/input")
//	@CacheLookup
//	WebElement purchaseFlight;

	public void purchaseFlight(String iName, String iAddress, String iCity, String iState, String iZipCode, String iCardType, 
			String iCardNumber, String iCardMonth, String iCardYear, String iNameOnCard) {
		try {
			
			driver.findElement(By.xpath("//*[@id=\"inputName\"]")).sendKeys(iName);
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id=\"address\"]")).sendKeys(iAddress);
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id=\"city\"]")).sendKeys(iCity);
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id=\"state\"]")).sendKeys(iState);
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id=\"zipCode\"]")).sendKeys(iZipCode);
			Thread.sleep(1000);
			WebElement creditCard = driver.findElement(By.id("cardType"));
			creditCard.click();
			Select dropDowncreditCard = new Select(creditCard);
			dropDowncreditCard.selectByVisibleText(iCardType);
			driver.findElement(By.id("creditCardNumber")).sendKeys(iCardNumber);
			driver.findElement(By.xpath("//*[@id=\"creditCardMonth\"]")).sendKeys(iCardMonth);
			Thread.sleep(1000);
			driver.findElement(By.xpath("//*[@id=\"creditCardYear\"]")).sendKeys(iCardYear);
			Thread.sleep(1000);
			driver.findElement(By.id("nameOnCard")).sendKeys(iNameOnCard);
			Thread.sleep(1000);
			driver.findElement(By.xpath("/html/body/div[2]/form/div[11]/div/input")).click();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
